﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace DEVJR
{
    public partial class F_Locacao : Form
    {
        public F_Locacao()
        {
            InitializeComponent();
        }
        private MySqlConnectionStringBuilder ConexaoBanco()
        {
            MySqlConnectionStringBuilder conexaoBD = new MySqlConnectionStringBuilder();
            conexaoBD.Server = "localhost";
            conexaoBD.Database = "devjr";
            conexaoBD.UserID = "root";
            conexaoBD.Password = "";
            conexaoBD.SslMode = MySql.Data.MySqlClient.MySqlSslMode.None;
            return (MySqlConnectionStringBuilder)conexaoBD;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lb_loc_Veic_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void P_CadCli_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Bt_Busca_Click(object sender, EventArgs e)
        {

        }

        private void Bt_Altera_Click(object sender, EventArgs e)
        {

        }

        private void bt_Sair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dtg_MD_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder conexaoBD = ConexaoBanco();
            MySqlConnection realizaConexacoBD = new MySqlConnection(conexaoBD.ToString());
            try
            {
                realizaConexacoBD.Open(); //Abre a conexão com o banco
                MySqlCommand comandoMySql = realizaConexacoBD.CreateCommand(); //Crio um comando SQL

                //comandoMySql.CommandText = "UPDATE cliente SET cli_cpf = '" + Convert.ToInt16(TB_CPF.Text) + "', " +
                comandoMySql.CommandText = "UPDATE cliente SET cli_cpf = '" + TB_CPF.Text + "', " +
                    "cli_senha = '" + TB_senha.Text + "', " +
                    "cli_nome = '" + TB_Nome.Text + "', " +
                    "cli_end = '" + TB_End.Text + "', " +
                    "cli_bairro = '" + CB_Bairro.Text + "', " +
                    //"cli_cep = " + Convert.ToInt16(TB_CEP.Text) +
                    "cli_cep = '" + TB_CEP.Text + "', " +
                    "cli_cidade = '" + TB_Cidade.Text + "', " +
                    "cli_uf = '" + CB_UF.Text + "', " +
                    "cli_email = '" + TB_Email.Text + "', " +
                    "cli_fone_w = '" + TB_FoneW.Text + "' " +
                    //"cli_fone_w = " + Convert.ToInt16(TB_FoneW.Text) +
                    " WHERE id = '" + TB_CodCli.Text + "'";
                comandoMySql.ExecuteNonQuery();

                realizaConexacoBD.Close(); // Fecho a conexão com o banco
                MessageBox.Show("Dados Atualizado com Sucesso!"); //Exibo mensagem de aviso
                //AtualizaGrid();
                LimparCampos();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder conexaoBD = ConexaoBanco();
            MySqlConnection realizaConexacoBD = new MySqlConnection(conexaoBD.ToString());
            try
            {
                realizaConexacoBD.Open();

                MySqlCommand comandoMySql = realizaConexacoBD.CreateCommand();

                //INSERT INTO `cliente` (`id`, `cli_cpf`, `cli_nome`, `cli_end`, `cli_bairro`, `cli_cep`, `cli_cidade`, `cli_uf`, `cli_email`, `cli_fone_w`)
                //VALUES(NULL, 'LIMPEZA', 'SABAO EM PÓ', '5', '7', '1');

                comandoMySql.CommandText = "INSERT INTO cliente(cli_senha,cli_cpf, cli_nome, cli_end, cli_bairro, cli_cep, cli_cidade, cli_uf, cli_email, cli_fone_w)" +
                        "VALUES('" + TB_senha.Text + "', '" + TB_CPF.Text + "', '" + TB_Nome.Text + "', '" + TB_End.Text + "', '" + CB_Bairro.Text + "', '" + TB_CEP.Text + "', '" + TB_Cidade.Text + "', '" + CB_UF.Text + "', '" + TB_Email.Text + "', '" + TB_FoneW.Text + "')";
                comandoMySql.ExecuteNonQuery();

                realizaConexacoBD.Close();
                MessageBox.Show("Cliente cadastrado com Sucesso!");
                //AtualizaGrid();
                LimparCampos();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder conexaoBD = ConexaoBanco();
            MySqlConnection realizaConexacoBD = new MySqlConnection(conexaoBD.ToString());
            try
            {
                realizaConexacoBD.Open();

                MySqlCommand comandoMySql = realizaConexacoBD.CreateCommand();
                comandoMySql.CommandText = "SELECT * FROM cliente WHERE cli_cpf = '" + TB_CPF.Text + "'";
                MySqlDataReader reader = comandoMySql.ExecuteReader();

                //dgLocadora.Rows.Clear();

                while (reader.Read())
                {
                    TB_CodCli.Text = reader.GetString(0);   //id
                    TB_senha.Text = reader.GetString(1);    // SENHA
                    TB_CPF.Text = reader.GetString(2);      //CPF
                    TB_Nome.Text = reader.GetString(3);     //NOME
                    TB_End.Text = reader.GetString(4);      //ENDEREÇO
                    CB_Bairro.Text = reader.GetString(5);   //BAIRRO
                    TB_CEP.Text = reader.GetString(6);      //CEP
                    TB_Cidade.Text = reader.GetString(7);   //CIDADE
                    CB_UF.Text = reader.GetString(8);       //UF
                    TB_Email.Text = reader.GetString(9);    //EMAIL
                    TB_FoneW.Text = reader.GetString(10);    //FONE COM WHATS
                }

                realizaConexacoBD.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Can not open connection ! ");
                Console.WriteLine(ex.Message);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }
        private void LimparCampos()
        {
            TB_CodCli.Clear();              //id
            TB_senha.Clear();               //SENHA
            TB_CPF.Clear();                 //CPF
            TB_Nome.Clear();                //NOME
            TB_End.Clear();                 //ENDEREÇO
            CB_Bairro.SelectedIndex = -1;   //BAIRRO
            TB_CEP.Clear();                 //CEP
            TB_Cidade.Clear();              //CIDADE
            CB_UF.SelectedIndex = -1;       //UF
            TB_Email.Clear();               //EMAIL
            TB_FoneW.Clear();	            //FONE COM WHATS
        }

        private void btExcluir_Click(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder conexaoBD = ConexaoBanco();
            MySqlConnection realizaConexacoBD = new MySqlConnection(conexaoBD.ToString());
            try
            {
                realizaConexacoBD.Open(); //Abre a conexão com o banco

                MySqlCommand comandoMySql = realizaConexacoBD.CreateCommand(); //Crio um comando SQL
                                                                               // "DELETE FROM filme WHERE idFilme = "+ textBoxId.Text +""
                                                                               //comandoMySql.CommandText = "DELETE FROM filme WHERE idFilme = " + tbID.Text + "";
                comandoMySql.CommandText = "DELETE from cliente WHERE cliente.id = " + TB_CodCli.Text + "";

                comandoMySql.ExecuteNonQuery();

                realizaConexacoBD.Close(); // Fecho a conexão com o banco
                MessageBox.Show("Cliente Deletado com Sucesso!"); //Exibo mensagem de aviso
                                                         //AtualizaGrid();
                LimparCampos();
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Não foi possivel abrir a conexão! ");
                Console.WriteLine(ex.Message);
            }
        }

        private void TB_CodCli_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
