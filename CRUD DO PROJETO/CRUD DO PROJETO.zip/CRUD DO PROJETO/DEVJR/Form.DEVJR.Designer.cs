﻿
namespace DEVJR
{
    partial class F_DevJr
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(F_DevJr));
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btSair = new System.Windows.Forms.Button();
            this.bt_Veiculos = new System.Windows.Forms.Button();
            this.bt_Relatorio = new System.Windows.Forms.Button();
            this.bt_Locar = new System.Windows.Forms.Button();
            this.bt_CadCli2 = new System.Windows.Forms.Button();
            this.P_Locar = new System.Windows.Forms.Panel();
            this.cb_L_devolver = new System.Windows.Forms.CheckBox();
            this.bt_L_Excluir = new System.Windows.Forms.Button();
            this.bt_L_Cad = new System.Windows.Forms.Button();
            this.dtp_L_dtadev = new System.Windows.Forms.DateTimePicker();
            this.bt_L_limpar = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.bt_L_altera = new System.Windows.Forms.Button();
            this.dtp_L_dtaloc = new System.Windows.Forms.DateTimePicker();
            this.bt_L_lista = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_L_codcli = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_L_CodLoc = new System.Windows.Forms.TextBox();
            this.tb_L_obs = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.tb_L_valdia = new System.Windows.Forms.TextBox();
            this.lb_loc_Veic = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.tb_L_codveic = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lOCAÇÃOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vENDASToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.P_Locar.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStripContainer1
            // 
            this.toolStripContainer1.BottomToolStripPanelVisible = false;
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.toolStripContainer1.ContentPanel.AutoScroll = true;
            this.toolStripContainer1.ContentPanel.Controls.Add(this.pictureBox4);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.pictureBox3);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.pictureBox2);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.panel1);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.P_Locar);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.panel2);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(962, 791);
            this.toolStripContainer1.ContentPanel.Load += new System.EventHandler(this.toolStripContainer1_ContentPanel_Load);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            // 
            // toolStripContainer1.LeftToolStripPanel
            // 
            this.toolStripContainer1.LeftToolStripPanel.BackColor = System.Drawing.SystemColors.WindowText;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.RightToolStripPanelVisible = false;
            this.toolStripContainer1.Size = new System.Drawing.Size(962, 791);
            this.toolStripContainer1.TabIndex = 4;
            this.toolStripContainer1.Text = "toolStripContainer1";
            this.toolStripContainer1.TopToolStripPanelVisible = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.InitialImage")));
            this.pictureBox4.Location = new System.Drawing.Point(123, 640);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(68, 72);
            this.pictureBox4.TabIndex = 8;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.InitialImage")));
            this.pictureBox3.Location = new System.Drawing.Point(49, 640);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(68, 72);
            this.pictureBox3.TabIndex = 7;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.InitialImage")));
            this.pictureBox2.Location = new System.Drawing.Point(713, 640);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(199, 72);
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.LightGray;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.btSair);
            this.panel1.Controls.Add(this.bt_Veiculos);
            this.panel1.Controls.Add(this.bt_Relatorio);
            this.panel1.Controls.Add(this.bt_Locar);
            this.panel1.Controls.Add(this.bt_CadCli2);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(961, 116);
            this.panel1.TabIndex = 4;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(20, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(60, 60);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // btSair
            // 
            this.btSair.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btSair.BackColor = System.Drawing.Color.Transparent;
            this.btSair.FlatAppearance.BorderSize = 0;
            this.btSair.FlatAppearance.MouseDownBackColor = System.Drawing.Color.CadetBlue;
            this.btSair.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSair.ForeColor = System.Drawing.Color.DimGray;
            this.btSair.Image = global::DEVJR.Properties.Resources.sair;
            this.btSair.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btSair.Location = new System.Drawing.Point(697, 2);
            this.btSair.Name = "btSair";
            this.btSair.Size = new System.Drawing.Size(145, 112);
            this.btSair.TabIndex = 4;
            this.btSair.Text = "&SAIR";
            this.btSair.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btSair.UseVisualStyleBackColor = false;
            this.btSair.Click += new System.EventHandler(this.btSair_Click);
            // 
            // bt_Veiculos
            // 
            this.bt_Veiculos.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bt_Veiculos.BackColor = System.Drawing.Color.Transparent;
            this.bt_Veiculos.FlatAppearance.BorderSize = 0;
            this.bt_Veiculos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.CadetBlue;
            this.bt_Veiculos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bt_Veiculos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_Veiculos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Veiculos.ForeColor = System.Drawing.Color.Black;
            this.bt_Veiculos.Image = global::DEVJR.Properties.Resources.veiculos;
            this.bt_Veiculos.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.bt_Veiculos.Location = new System.Drawing.Point(253, 2);
            this.bt_Veiculos.Name = "bt_Veiculos";
            this.bt_Veiculos.Size = new System.Drawing.Size(145, 112);
            this.bt_Veiculos.TabIndex = 3;
            this.bt_Veiculos.Text = "&VEÍCULO";
            this.bt_Veiculos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.bt_Veiculos.UseVisualStyleBackColor = false;
            this.bt_Veiculos.Click += new System.EventHandler(this.Button2_Click);
            // 
            // bt_Relatorio
            // 
            this.bt_Relatorio.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bt_Relatorio.BackColor = System.Drawing.Color.Transparent;
            this.bt_Relatorio.FlatAppearance.BorderSize = 0;
            this.bt_Relatorio.FlatAppearance.MouseDownBackColor = System.Drawing.Color.CadetBlue;
            this.bt_Relatorio.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bt_Relatorio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_Relatorio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Relatorio.ForeColor = System.Drawing.Color.Black;
            this.bt_Relatorio.Image = global::DEVJR.Properties.Resources.relatorios;
            this.bt_Relatorio.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.bt_Relatorio.Location = new System.Drawing.Point(549, 2);
            this.bt_Relatorio.Name = "bt_Relatorio";
            this.bt_Relatorio.Size = new System.Drawing.Size(145, 112);
            this.bt_Relatorio.TabIndex = 2;
            this.bt_Relatorio.Text = "&RELATORIOS";
            this.bt_Relatorio.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.bt_Relatorio.UseVisualStyleBackColor = false;
            this.bt_Relatorio.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // bt_Locar
            // 
            this.bt_Locar.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bt_Locar.BackColor = System.Drawing.Color.Transparent;
            this.bt_Locar.FlatAppearance.BorderSize = 0;
            this.bt_Locar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.CadetBlue;
            this.bt_Locar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bt_Locar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_Locar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Locar.ForeColor = System.Drawing.Color.Black;
            this.bt_Locar.Image = global::DEVJR.Properties.Resources.locar;
            this.bt_Locar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.bt_Locar.Location = new System.Drawing.Point(105, 2);
            this.bt_Locar.Name = "bt_Locar";
            this.bt_Locar.Size = new System.Drawing.Size(145, 112);
            this.bt_Locar.TabIndex = 1;
            this.bt_Locar.Text = "&LOCAR";
            this.bt_Locar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.bt_Locar.UseVisualStyleBackColor = false;
            this.bt_Locar.Click += new System.EventHandler(this.bt_locação_Click);
            // 
            // bt_CadCli2
            // 
            this.bt_CadCli2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bt_CadCli2.BackColor = System.Drawing.Color.Transparent;
            this.bt_CadCli2.FlatAppearance.BorderSize = 0;
            this.bt_CadCli2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.CadetBlue;
            this.bt_CadCli2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bt_CadCli2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_CadCli2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_CadCli2.ForeColor = System.Drawing.Color.Black;
            this.bt_CadCli2.Image = global::DEVJR.Properties.Resources.clientes;
            this.bt_CadCli2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.bt_CadCli2.Location = new System.Drawing.Point(401, 2);
            this.bt_CadCli2.Name = "bt_CadCli2";
            this.bt_CadCli2.Size = new System.Drawing.Size(145, 112);
            this.bt_CadCli2.TabIndex = 0;
            this.bt_CadCli2.Text = "&CLIENTES";
            this.bt_CadCli2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.bt_CadCli2.UseVisualStyleBackColor = false;
            this.bt_CadCli2.Click += new System.EventHandler(this.Button1_Click);
            // 
            // P_Locar
            // 
            this.P_Locar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.P_Locar.AutoSize = true;
            this.P_Locar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.P_Locar.Controls.Add(this.cb_L_devolver);
            this.P_Locar.Controls.Add(this.bt_L_Excluir);
            this.P_Locar.Controls.Add(this.bt_L_Cad);
            this.P_Locar.Controls.Add(this.dtp_L_dtadev);
            this.P_Locar.Controls.Add(this.bt_L_limpar);
            this.P_Locar.Controls.Add(this.label4);
            this.P_Locar.Controls.Add(this.bt_L_altera);
            this.P_Locar.Controls.Add(this.dtp_L_dtaloc);
            this.P_Locar.Controls.Add(this.bt_L_lista);
            this.P_Locar.Controls.Add(this.label6);
            this.P_Locar.Controls.Add(this.label3);
            this.P_Locar.Controls.Add(this.label7);
            this.P_Locar.Controls.Add(this.label2);
            this.P_Locar.Controls.Add(this.tb_L_codcli);
            this.P_Locar.Controls.Add(this.label1);
            this.P_Locar.Controls.Add(this.tb_L_CodLoc);
            this.P_Locar.Controls.Add(this.tb_L_obs);
            this.P_Locar.Controls.Add(this.label16);
            this.P_Locar.Controls.Add(this.tb_L_valdia);
            this.P_Locar.Controls.Add(this.lb_loc_Veic);
            this.P_Locar.Controls.Add(this.label19);
            this.P_Locar.Controls.Add(this.tb_L_codveic);
            this.P_Locar.Location = new System.Drawing.Point(49, 211);
            this.P_Locar.Name = "P_Locar";
            this.P_Locar.Size = new System.Drawing.Size(863, 350);
            this.P_Locar.TabIndex = 2;
            this.P_Locar.Visible = false;
            this.P_Locar.Paint += new System.Windows.Forms.PaintEventHandler(this.P_CadCli_Paint);
            // 
            // cb_L_devolver
            // 
            this.cb_L_devolver.AutoSize = true;
            this.cb_L_devolver.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_L_devolver.Location = new System.Drawing.Point(204, 192);
            this.cb_L_devolver.Name = "cb_L_devolver";
            this.cb_L_devolver.Size = new System.Drawing.Size(97, 17);
            this.cb_L_devolver.TabIndex = 79;
            this.cb_L_devolver.Text = "DEVOLVIDO";
            this.cb_L_devolver.UseVisualStyleBackColor = true;
            // 
            // bt_L_Excluir
            // 
            this.bt_L_Excluir.BackColor = System.Drawing.Color.OrangeRed;
            this.bt_L_Excluir.FlatAppearance.BorderSize = 0;
            this.bt_L_Excluir.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.bt_L_Excluir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.bt_L_Excluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_L_Excluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_L_Excluir.ForeColor = System.Drawing.Color.White;
            this.bt_L_Excluir.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_L_Excluir.Location = new System.Drawing.Point(366, 242);
            this.bt_L_Excluir.Name = "bt_L_Excluir";
            this.bt_L_Excluir.Size = new System.Drawing.Size(71, 45);
            this.bt_L_Excluir.TabIndex = 77;
            this.bt_L_Excluir.Text = "E&XCLUIR";
            this.bt_L_Excluir.UseVisualStyleBackColor = false;
            this.bt_L_Excluir.Click += new System.EventHandler(this.btExcluir_Click);
            // 
            // bt_L_Cad
            // 
            this.bt_L_Cad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(47)))), ((int)(((byte)(50)))));
            this.bt_L_Cad.FlatAppearance.BorderSize = 0;
            this.bt_L_Cad.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.bt_L_Cad.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.bt_L_Cad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_L_Cad.ForeColor = System.Drawing.Color.White;
            this.bt_L_Cad.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_L_Cad.Location = new System.Drawing.Point(645, 242);
            this.bt_L_Cad.Name = "bt_L_Cad";
            this.bt_L_Cad.Size = new System.Drawing.Size(144, 45);
            this.bt_L_Cad.TabIndex = 76;
            this.bt_L_Cad.Text = "&CADASTRAR";
            this.bt_L_Cad.UseVisualStyleBackColor = false;
            this.bt_L_Cad.Click += new System.EventHandler(this.bt_C_cad_Click);
            // 
            // dtp_L_dtadev
            // 
            this.dtp_L_dtadev.CustomFormat = "";
            this.dtp_L_dtadev.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.dtp_L_dtadev.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.dtp_L_dtadev.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_L_dtadev.Location = new System.Drawing.Point(203, 160);
            this.dtp_L_dtadev.Name = "dtp_L_dtadev";
            this.dtp_L_dtadev.Size = new System.Drawing.Size(188, 29);
            this.dtp_L_dtadev.TabIndex = 56;
            this.dtp_L_dtadev.ValueChanged += new System.EventHandler(this.dtp_L_dtadev_ValueChanged);
            // 
            // bt_L_limpar
            // 
            this.bt_L_limpar.BackColor = System.Drawing.Color.Orange;
            this.bt_L_limpar.FlatAppearance.BorderSize = 0;
            this.bt_L_limpar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.bt_L_limpar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.bt_L_limpar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_L_limpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_L_limpar.ForeColor = System.Drawing.Color.White;
            this.bt_L_limpar.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_L_limpar.Location = new System.Drawing.Point(304, 242);
            this.bt_L_limpar.Name = "bt_L_limpar";
            this.bt_L_limpar.Size = new System.Drawing.Size(56, 45);
            this.bt_L_limpar.TabIndex = 73;
            this.bt_L_limpar.Text = "L&IMPAR";
            this.bt_L_limpar.UseVisualStyleBackColor = false;
            this.bt_L_limpar.Click += new System.EventHandler(this.button6_Click_1);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(68, 168);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 13);
            this.label4.TabIndex = 55;
            this.label4.Text = "Previsão de Devolução:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // bt_L_altera
            // 
            this.bt_L_altera.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(98)))), ((int)(((byte)(97)))));
            this.bt_L_altera.FlatAppearance.BorderSize = 0;
            this.bt_L_altera.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.bt_L_altera.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.bt_L_altera.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_L_altera.ForeColor = System.Drawing.Color.White;
            this.bt_L_altera.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_L_altera.Location = new System.Drawing.Point(544, 242);
            this.bt_L_altera.Name = "bt_L_altera";
            this.bt_L_altera.Size = new System.Drawing.Size(94, 45);
            this.bt_L_altera.TabIndex = 75;
            this.bt_L_altera.Text = "&ALTERAR";
            this.bt_L_altera.UseVisualStyleBackColor = false;
            this.bt_L_altera.Click += new System.EventHandler(this.bt_C_altera_Click);
            // 
            // dtp_L_dtaloc
            // 
            this.dtp_L_dtaloc.Checked = false;
            this.dtp_L_dtaloc.CustomFormat = "DD-MM-YYYY";
            this.dtp_L_dtaloc.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.dtp_L_dtaloc.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_L_dtaloc.Location = new System.Drawing.Point(203, 125);
            this.dtp_L_dtaloc.Name = "dtp_L_dtaloc";
            this.dtp_L_dtaloc.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dtp_L_dtaloc.Size = new System.Drawing.Size(188, 29);
            this.dtp_L_dtaloc.TabIndex = 54;
            // 
            // bt_L_lista
            // 
            this.bt_L_lista.BackColor = System.Drawing.Color.CadetBlue;
            this.bt_L_lista.FlatAppearance.BorderSize = 0;
            this.bt_L_lista.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.bt_L_lista.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Teal;
            this.bt_L_lista.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_L_lista.ForeColor = System.Drawing.Color.White;
            this.bt_L_lista.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.bt_L_lista.Location = new System.Drawing.Point(443, 242);
            this.bt_L_lista.Name = "bt_L_lista";
            this.bt_L_lista.Size = new System.Drawing.Size(94, 45);
            this.bt_L_lista.TabIndex = 74;
            this.bt_L_lista.Text = "&LISTAR";
            this.bt_L_lista.UseVisualStyleBackColor = false;
            this.bt_L_lista.Click += new System.EventHandler(this.bt_C_lista_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(199, 265);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 22);
            this.label6.TabIndex = 72;
            this.label6.Text = "LOCAÇÃO";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(96, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 13);
            this.label3.TabIndex = 53;
            this.label3.Text = "Data de Locação:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(169, 244);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(125, 22);
            this.label7.TabIndex = 71;
            this.label7.Text = "CONTROLE DE";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(96, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 13);
            this.label2.TabIndex = 50;
            this.label2.Text = "Código do Cliente:";
            // 
            // tb_L_codcli
            // 
            this.tb_L_codcli.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.tb_L_codcli.Location = new System.Drawing.Point(203, 90);
            this.tb_L_codcli.Name = "tb_L_codcli";
            this.tb_L_codcli.Size = new System.Drawing.Size(108, 29);
            this.tb_L_codcli.TabIndex = 51;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(84, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 13);
            this.label1.TabIndex = 48;
            this.label1.Text = "CÓDIGO LOCAÇÃO:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // tb_L_CodLoc
            // 
            this.tb_L_CodLoc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_L_CodLoc.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.tb_L_CodLoc.Location = new System.Drawing.Point(203, 55);
            this.tb_L_CodLoc.Name = "tb_L_CodLoc";
            this.tb_L_CodLoc.Size = new System.Drawing.Size(108, 29);
            this.tb_L_CodLoc.TabIndex = 49;
            // 
            // tb_L_obs
            // 
            this.tb_L_obs.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.tb_L_obs.Location = new System.Drawing.Point(456, 125);
            this.tb_L_obs.Multiline = true;
            this.tb_L_obs.Name = "tb_L_obs";
            this.tb_L_obs.Size = new System.Drawing.Size(333, 81);
            this.tb_L_obs.TabIndex = 38;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label16.Location = new System.Drawing.Point(414, 128);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(32, 13);
            this.label16.TabIndex = 39;
            this.label16.Text = "Obs.:";
            // 
            // tb_L_valdia
            // 
            this.tb_L_valdia.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.tb_L_valdia.Location = new System.Drawing.Point(648, 90);
            this.tb_L_valdia.Name = "tb_L_valdia";
            this.tb_L_valdia.Size = new System.Drawing.Size(141, 29);
            this.tb_L_valdia.TabIndex = 32;
            // 
            // lb_loc_Veic
            // 
            this.lb_loc_Veic.AutoSize = true;
            this.lb_loc_Veic.Location = new System.Drawing.Point(348, 98);
            this.lb_loc_Veic.Name = "lb_loc_Veic";
            this.lb_loc_Veic.Size = new System.Drawing.Size(98, 13);
            this.lb_loc_Veic.TabIndex = 29;
            this.lb_loc_Veic.Text = "Código do Veículo:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label19.Location = new System.Drawing.Point(587, 98);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(54, 13);
            this.label19.TabIndex = 33;
            this.label19.Text = "Diária R$:";
            // 
            // tb_L_codveic
            // 
            this.tb_L_codveic.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.tb_L_codveic.Location = new System.Drawing.Point(456, 90);
            this.tb_L_codveic.Name = "tb_L_codveic";
            this.tb_L_codveic.Size = new System.Drawing.Size(108, 29);
            this.tb_L_codveic.TabIndex = 30;
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Location = new System.Drawing.Point(0, 111);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(962, 680);
            this.panel2.TabIndex = 9;
            // 
            // lOCAÇÃOToolStripMenuItem
            // 
            this.lOCAÇÃOToolStripMenuItem.Name = "lOCAÇÃOToolStripMenuItem";
            this.lOCAÇÃOToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.lOCAÇÃOToolStripMenuItem.Text = "&LOCAÇÃO";
            this.lOCAÇÃOToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lOCAÇÃOToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            this.lOCAÇÃOToolStripMenuItem.Click += new System.EventHandler(this.LOCAÇÃOToolStripMenuItem_Click);
            // 
            // vENDASToolStripMenuItem
            // 
            this.vENDASToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.vENDASToolStripMenuItem.Name = "vENDASToolStripMenuItem";
            this.vENDASToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.vENDASToolStripMenuItem.Text = "V&ENDAS";
            this.vENDASToolStripMenuItem.Click += new System.EventHandler(this.VENDASToolStripMenuItem_Click);
            // 
            // F_DevJr
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(962, 791);
            this.Controls.Add(this.toolStripContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "F_DevJr";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DEV JR - Rent a Car";
            this.Load += new System.EventHandler(this.F_DevJr_Load);
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.ContentPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.P_Locar.ResumeLayout(false);
            this.P_Locar.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.ToolStripMenuItem lOCAÇÃOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vENDASToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button bt_CadCli2;
        private System.Windows.Forms.Button bt_Locar;
        private System.Windows.Forms.Button bt_Relatorio;
        private System.Windows.Forms.Button bt_Veiculos;
        private System.Windows.Forms.Panel P_Locar;
        private System.Windows.Forms.Button btSair;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox tb_L_obs;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox tb_L_valdia;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox tb_L_codveic;
        private System.Windows.Forms.Label lb_loc_Veic;
        private System.Windows.Forms.DateTimePicker dtp_L_dtadev;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtp_L_dtaloc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_L_codcli;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_L_CodLoc;
        private System.Windows.Forms.Button bt_L_Excluir;
        private System.Windows.Forms.Button bt_L_Cad;
        private System.Windows.Forms.Button bt_L_limpar;
        private System.Windows.Forms.Button bt_L_altera;
        private System.Windows.Forms.Button bt_L_lista;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.CheckBox cb_L_devolver;
        private System.Windows.Forms.Panel panel2;
    }
}

